<?php
include '../../../class/include.php';
header('Content-Type: application/json; charset=UTF8'); 

if (!isset($_POST['student_id']) || empty(trim($_POST['student_id']))) {
    echo json_encode([
        'status' => 'error',
        'message' => 'NIC or MIS number is required.'
    ]);
    exit;
}

$student_id = trim($_POST['student_id']);

// Fetch all students with the given NIC or MIS number
$students = Student::getStudentByNIC1($student_id);

if (count($students) > 0) {
    $data = [];

    foreach ($students as $student) {
        $COURSE = new Course($student['course_id']);
        
        $data[] = [
            'full_name' => $student['fname'] . ' ' . $student['lname'],
            'nic' => $student['nic'],
            'mis_number' => $student['id'],
            'course' => $student['course_id'],
            'course_name' => $COURSE->cname,
            'year' => $student['year'],
            'batch' => $student['batch']
        ];
    }

    echo json_encode([
        'status' => 'success',
        'data' => $data
    ]);
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'No student found with the given NIC or MIS number.'
    ]);
}
