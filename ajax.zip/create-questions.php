<?php
include '../class/include.php';
include './auth.php';

$id = $_GET['id'];
$COURSE = new Course($id);
$COURSETRADE = new CourseTrade($COURSE->tradecode);
?>
<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8" />
    <title>Create Questions | Sri Lanka Youth Services</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- DataTables -->
    <link href="assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />

    <!-- Responsive datatable examples -->
    <link href="assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />

    <link href="assets/libs/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
    <!-- Bootstrap Css -->
    <link href="assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
    <link href="plugin/sweetalert/sweetalert.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/preloader.css" rel="stylesheet" type="text/css" />

</head>

<body class="someBlock">

    <!-- <body data-layout="horizontal" data-topbar="colored"> -->

    <!-- Begin page -->
    <div id="layout-wrapper">


        <?php include './top-header.php'; ?>
        <!-- ========== Left Sidebar Start ========== -->
        <?php include './navigation.php'; ?>
        <!-- Left Sidebar End -->



        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">

                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-flex align-items-center justify-content-between">
                                <h4 class="mb-0">Create Questions</h4>

                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                                        <li class="breadcrumb-item"><a href="manage-courses.php">Courses</a></li>
                                        <li class="breadcrumb-item active">Manage Questions</li>
                                    </ol>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- end page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">

                                    <h4 class="card-title">Add Questions</h4>
                                    <form id="form-data">
                                        <div class="mb-3 row">
                                            <label for="example-text-input" class="col-md-2 col-form-label">Course Trade</label>
                                            <div class="col-md-10">
                                                <input class="form-control" type="text" value="<?php echo $COURSETRADE->trade_name ?>" readonly="">
                                            </div>
                                        </div>
                                        <div class="mb-3 row">
                                            <label for="example-text-input" class="col-md-2 col-form-label">Course Name</label>
                                            <div class="col-md-10">
                                                <input class="form-control" type="text" value="<?php echo $COURSE->cname ?>" readonly="">
                                            </div>
                                        </div>
                                        <div class="mb-3 row">
                                            <label for="example-text-input" class="col-md-2 col-form-label">Course Id</label>
                                            <div class="col-md-10">
                                                <input class="form-control" type="text" value="<?php echo $COURSE->courseid ?>" readonly="">
                                            </div>
                                        </div>
                                        <div class="mb-3 row">
                                            <label for="example-search-input" class="col-md-2 col-form-label">Course Module</label>
                                            <div class="col-md-10">
                                                <select class="form-control select2" name="module" id="module">
                                                    <option value="">-- Select Modules -- </option>
                                                    <?php
                                                    $COURSEMODULE = new CourseModule(NULL);
                                                    foreach ($COURSEMODULE->getModulesByCourse($COURSE->courseid) as $module) {
                                                    ?>
                                                        <option value="<?= $module['id'] ?>"><?= $module['code'] . ' - ' . $module['name'] ?></option>
                                                    <?php
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="mb-3 row">
                                            <label for="example-text-input" class="col-md-2 col-form-label">Add Image for Question</label>
                                            <div class="col-md-10">
                                                <input class="form-control" type="file" name="image_name">
                                            </div>
                                        </div>


                                        <div class="mb-3 row">
                                            <label for="example-text-input" class="col-md-2 col-form-label">Image Answer 1</label>
                                            <div class="col-md-10">
                                                <input class="form-control" type="file" name="image_answer_1">
                                            </div>
                                        </div>
                                        <div class="mb-3 row">
                                            <label for="example-text-input" class="col-md-2 col-form-label">Image Answer 2</label>
                                            <div class="col-md-10">
                                                <input class="form-control" type="file" name="image_answer_2">
                                            </div>
                                        </div>
                                        <div class="mb-3 row">
                                            <label for="example-text-input" class="col-md-2 col-form-label">Image Answer 3</label>
                                            <div class="col-md-10">
                                                <input class="form-control" type="file" name="image_answer_3">
                                            </div>
                                        </div>
                                        <div class="mb-3 row">
                                            <label for="example-text-input" class="col-md-2 col-form-label">Image Answer 4</label>
                                            <div class="col-md-10">
                                                <input class="form-control" type="file" name="image_answer_4">
                                            </div>
                                        </div>

                                        <!-- Question -->
                                        <?php
                                        if ($COURSE->english_lang == 1) {
                                        ?>
                                            <!-- English Question -->
                                            <div class="mb-3 row">
                                                <label for="example-text-input" class="col-md-2 col-form-label">Add Question (English)</label>
                                                <div class="col-md-10">
                                                    <textarea style="background: white;" class="form-control question" id="question" name="question">  </textarea>

                                                </div>
                                            </div>
                                        <?php
                                        }
                                        if ($COURSE->sinhala_lang == 1) {
                                        ?>
                                            <!-- Sinhala Question -->
                                            <div class="mb-3 row">
                                                <label for="example-text-input" class="col-md-2 col-form-label">Add Question (Sinhala)</label>
                                                <div class="col-md-10">
                                                    <textarea style="background: white;" class="form-control question" id="question_sinhala" name="question_sinhala">  </textarea>

                                                </div>
                                            </div>
                                        <?php
                                        }
                                        if ($COURSE->tamil_lang == 1) {
                                        ?>
                                            <!-- Tamil Question -->
                                            <div class="mb-3 row">
                                                <label for="example-text-input" class="col-md-2 col-form-label">Add Question (Tamil)</label>
                                                <div class="col-md-10">
                                                    <textarea style="background: white;" class="form-control question" id="question_tamil" name="question_tamil">  </textarea>

                                                </div>
                                            </div>
                                        <?php
                                        }
                                        ?>

                                        <!-- Answer 1 -->
                                        <?php
                                        if ($COURSE->english_lang == 1) {
                                        ?>
                                            <!-- English -->
                                            <div class="mb-3 row">
                                                <label for="example-text-input" class="col-md-2 col-form-label">Answer 1 (English)</label>
                                                <div class="col-md-10">
                                                    <textarea style="background: white;" class="form-control question" id="answer_1" name="answer_1">  </textarea>

                                                </div>
                                            </div>
                                        <?php
                                        }
                                        if ($COURSE->sinhala_lang == 1) {
                                        ?>
                                            <!-- Sinhala -->
                                            <div class="mb-3 row">
                                                <label for="example-text-input" class="col-md-2 col-form-label">Answer 1 (Sinhala)</label>
                                                <div class="col-md-10">
                                                    <textarea style="background: white;" class="form-control question" id="answer_1_sinhala" name="answer_1_sinhala">  </textarea>

                                                </div>
                                            </div>
                                        <?php
                                        }
                                        if ($COURSE->tamil_lang == 1) {
                                        ?>
                                            <!-- Tamil -->
                                            <div class="mb-3 row">
                                                <label for="example-text-input" class="col-md-2 col-form-label">Answer 1 (Tamil)</label>
                                                <div class="col-md-10">
                                                    <textarea style="background: white;" class="form-control question" id="answer_1_tamil" name="answer_1_tamil">  </textarea>

                                                </div>
                                            </div>
                                        <?php
                                        }
                                        ?>


                                        <!-- Answer 2 -->
                                        <?php
                                        if ($COURSE->english_lang == 1) {
                                        ?>
                                            <!-- English -->
                                            <div class="mb-3 row">
                                                <label for="example-text-input" class="col-md-2 col-form-label">Answer 2 (English)</label>
                                                <div class="col-md-10">
                                                    <textarea style="background: white;" class="form-control question" id="answer_2" name="answer_2">  </textarea>

                                                </div>
                                            </div>
                                        <?php
                                        }
                                        if ($COURSE->sinhala_lang == 1) {
                                        ?>
                                            <!-- Sinhala -->
                                            <div class="mb-3 row">
                                                <label for="example-text-input" class="col-md-2 col-form-label">Answer 2 (Sinhala)</label>
                                                <div class="col-md-10">
                                                    <textarea style="background: white;" class="form-control question" id="answer_2_sinhala" name="answer_2_sinhala">  </textarea>

                                                </div>
                                            </div>
                                        <?php
                                        }
                                        if ($COURSE->tamil_lang == 1) {
                                        ?>
                                            <!-- Tamil -->
                                            <div class="mb-3 row">
                                                <label for="example-text-input" class="col-md-2 col-form-label">Answer 2 (Tamil)</label>
                                                <div class="col-md-10">
                                                    <textarea style="background: white;" class="form-control question" id="answer_2_tamil" name="answer_2_tamil">  </textarea>

                                                </div>
                                            </div>
                                        <?php
                                        }
                                        ?>

                                        <!-- Answer 3 -->
                                        <?php
                                        if ($COURSE->english_lang == 1) {
                                        ?>
                                            <!-- English -->
                                            <div class="mb-3 row">
                                                <label for="example-text-input" class="col-md-2 col-form-label">Answer 3 (English)</label>
                                                <div class="col-md-10">
                                                    <textarea style="background: white;" class="form-control question" id="answer_3" name="answer_3">  </textarea>

                                                </div>
                                            </div>
                                        <?php
                                        }
                                        if ($COURSE->sinhala_lang == 1) {
                                        ?>
                                            <!-- Sinhala -->
                                            <div class="mb-3 row">
                                                <label for="example-text-input" class="col-md-2 col-form-label">Answer 3 (Sinhala)</label>
                                                <div class="col-md-10">
                                                    <textarea style="background: white;" class="form-control question" id="answer_3_sinhala" name="answer_3_sinhala">  </textarea>

                                                </div>
                                            </div>
                                        <?php
                                        }
                                        if ($COURSE->tamil_lang == 1) {
                                        ?>
                                            <!-- Tamil -->
                                            <div class="mb-3 row">
                                                <label for="example-text-input" class="col-md-2 col-form-label">Answer 3 (Tamil)</label>
                                                <div class="col-md-10">
                                                    <textarea style="background: white;" class="form-control question" id="answer_3_tamil" name="answer_3_tamil">  </textarea>

                                                </div>
                                            </div>
                                        <?php
                                        }
                                        ?>

                                        <!-- Answer 4 -->
                                        <?php
                                        if ($COURSE->english_lang == 1) {
                                        ?>
                                            <!-- English -->
                                            <div class="mb-3 row">
                                                <label for="example-text-input" class="col-md-2 col-form-label">Answer 4 (English)</label>
                                                <div class="col-md-10">
                                                    <textarea style="background: white;" class="form-control question" id="answer_4" name="answer_4">  </textarea>

                                                </div>
                                            </div>
                                        <?php
                                        }
                                        if ($COURSE->sinhala_lang == 1) {
                                        ?>
                                            <!-- Sinhala -->
                                            <div class="mb-3 row">
                                                <label for="example-text-input" class="col-md-2 col-form-label">Answer 4 (Sinhala)</label>
                                                <div class="col-md-10">
                                                    <textarea style="background: white;" class="form-control question" id="answer_4_sinhala" name="answer_4_sinhala">  </textarea>

                                                </div>
                                            </div>
                                        <?php
                                        }
                                        if ($COURSE->tamil_lang == 1) {
                                        ?>
                                            <!-- Tamil -->
                                            <div class="mb-3 row">
                                                <label for="example-text-input" class="col-md-2 col-form-label">Answer 4 (Tamil)</label>
                                                <div class="col-md-10">
                                                    <textarea style="background: white;" class="form-control question" id="answer_4_tamil" name="answer_4_tamil">  </textarea>

                                                </div>
                                            </div>
                                        <?php
                                        }
                                        ?>

                                        <div class="mb-3 row">
                                            <label for="example-search-input" class="col-md-2 col-form-label">Select Correct Answer</label>
                                            <div class="col-md-10">
                                                <select class="form-control" name="correct_answer" id="correct_answer">
                                                    <option value="">-- Select the correct answer -- </option>
                                                    <option value="1">Answer 1</option>
                                                    <option value="2">Answer 2</option>
                                                    <option value="3">Answer 3</option>
                                                    <option value="4">Answer 4</option>
                                                </select>
                                            </div>
                                        </div>



                                        <div class="row">
                                            <div class="col-12" style="display: flex; justify-content: flex-end;margin-top: 15px;">
                                                <button class="btn btn-primary " type="submit" id="create">Create</button>

                                            </div>
                                            <input type="hidden" name="create">
                                            <input type="hidden" name="course" value="<?php echo $id ?>">

                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div> <!-- end col -->
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">

                                    <h4 class="card-title">Manage Questions</h4>


                                    <table class="table table-centered datatable dt-responsive nowrap table-card-list" style="border-collapse: collapse; border-spacing: 0 12px; width: 100%;">
                                        <thead>
                                            <tr class="bg-transparent">

                                                <th> Id</th>
                                                <th>Module</th>
                                                <th>Question</th>
                                                <th>Answer 1</th>
                                                <th>Answer 2</th>
                                                <th>Answer 3</th>
                                                <th>Answer 4</th>
                                                <th>Correct Answer </th>
                                                <th style="width: 120px;">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $QUESTION = new Question(NULL);
                                            foreach ($QUESTION->getQuestionById($id) as $key => $question) {
                                                $COURSE = new Course($question['course']);
                                                $MODULE = new CourseModule($question['module_id']);
                                                $key++;
                                            ?>
                                                <tr id="div<?php echo $question['id'] ?>">
                                                    <td><?php echo $key ?></td>
                                                    <td><?= $MODULE->code . ' - ' . $MODULE->name ?></td>
                                                    <td>
                                                        <?php
                                                        if ($COURSE->english_lang == 1) {
                                                            echo $question['question'];
                                                        } elseif ($COURSE->sinhala_lang == 1) {
                                                            echo $question['question_sinhala'];
                                                        } elseif ($COURSE->tamil_lang == 1) {
                                                            echo $question['question_tamil'];
                                                        }
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        if ($COURSE->english_lang == 1) {
                                                            echo $question['answer_1'];
                                                        } elseif ($COURSE->sinhala_lang == 1) {
                                                            echo $question['answer_1_sinhala'];
                                                        } elseif ($COURSE->tamil_lang == 1) {
                                                            echo $question['answer_1_tamil'];
                                                        }
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        if ($COURSE->english_lang == 1) {
                                                            echo $question['answer_2'];
                                                        } elseif ($COURSE->sinhala_lang == 1) {
                                                            echo $question['answer_2_sinhala'];
                                                        } elseif ($COURSE->tamil_lang == 1) {
                                                            echo $question['answer_2_tamil'];
                                                        }
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        if ($COURSE->english_lang == 1) {
                                                            echo $question['answer_3'];
                                                        } elseif ($COURSE->sinhala_lang == 1) {
                                                            echo $question['answer_3_sinhala'];
                                                        } elseif ($COURSE->tamil_lang == 1) {
                                                            echo $question['answer_3_tamil'];
                                                        }
                                                        ?>
                                                    </td>
                                                    <td><?php
                                                        if ($COURSE->english_lang == 1) {
                                                            echo $question['answer_4'];
                                                        } elseif ($COURSE->sinhala_lang == 1) {
                                                            echo $question['answer_4_sinhala'];
                                                        } elseif ($COURSE->tamil_lang == 1) {
                                                            echo $question['answer_4_tamil'];
                                                        }
                                                        ?></td>
                                                    <td><?php
                                                        $correct_answer = $question['correct_answer'];
                                                        if ($COURSE->english_lang == 1) {
                                                            echo $question['answer_' . $correct_answer];
                                                        } elseif ($COURSE->sinhala_lang == 1) {
                                                            echo $question['answer_' . $correct_answer . '_sinhala'];
                                                        } elseif ($COURSE->tamil_lang == 1) {
                                                            echo $question['answer_' . $correct_answer . '_tamil'];
                                                        }
                                                        ?></td>

                                                    <td>
                                                        <a href="edit-questions.php?id=<?php echo $question['id'] ?>">
                                                            <div class="badge bg-pill bg-soft-primary    font-size-14" type="button"><i class="fas fa-pencil-alt  p-1"></i></div>
                                                        </a> |

                                                        <div class="badge bg-pill bg-soft-danger font-size-14 delete-question " data-id="<?php echo $question['id'] ?>"><i class="fas fa-trash  p-1"></i></div>



                                                    </td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div> <!-- end col -->
                    </div>
                </div>
            </div>
        </div>
        <!-- end main content-->

    </div>
    <!-- END layout-wrapper -->



    <!-- Right bar overlay-->
    <div class="rightbar-overlay"></div>

    <!-- JAVASCRIPT -->
    <script src="assets/libs/jquery/jquery.min.js"></script>
    <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/libs/metismenu/metisMenu.min.js"></script>
    <script src="assets/libs/simplebar/simplebar.min.js"></script>
    <script src="assets/libs/node-waves/waves.min.js"></script>
    <script src="assets/libs/waypoints/lib/jquery.waypoints.min.js"></script>
    <script src="assets/libs/jquery.counterup/jquery.counterup.min.js"></script>

    <script src="assets/libs/select2/js/select2.min.js"></script>
    <!-- Required datatable js -->
    <script src="assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>

    <!-- Responsive examples -->
    <script src="assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>

    <!-- init js -->
    <script src="assets/js/pages/ecommerce-datatables.init.js"></script>
    <script src="assets/js/jquery.preloader.min.js" type="text/javascript"></script>
    <!-- App js -->
    <script src="assets/js/app.js"></script>
    <script src="ajax/js/question.js" type="text/javascript"></script>
    <script src="delete/js/question.js" type="text/javascript"></script>

    <script src="plugin/sweetalert/sweetalert.min.js" type="text/javascript"></script>
    <script src="assets/js/pages/form-advanced.init.js"></script>
    <!-- ckeditor -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/5.2.2/tinymce.min.js"></script>
    <script>
        tinymce.init({
            selector: '.question'
        });
    </script>


</body>

</html>