<?php
include_once '../class/include.php';

// Load Dompdf's autoloader
require_once 'plugin/dompdf/autoload.inc.php';

use Dompdf\Dompdf;

$paper_id = $_GET['id'] ?? '';
$period_id = $_GET['period_id'] ?? '';

$EXAM_PAPER = new ExamPaper($paper_id);
$COURSE = new Course($EXAM_PAPER->course_id);
$COURSETRADE = new CourseTrade($COURSE->tradecode);
$EXAMPERIOD = new ExamPeriod($EXAM_PAPER->exam_period_id);
$PAPER_QUES = new ExamPaperQuestions(null);
$all_selected_questions = $PAPER_QUES->getQuestionsByExamPaperId($paper_id);

ob_start();
?>

<style>
 @font-face {
    font-family: 'NotoSansSinhala';
    src: url('plugin/dompdf/lib/fonts/NotoSansTamil-VariableFont_wdth,wght.ttf') format('truetype');
    font-weight: normal;
    font-style: normal;
}
    /* rest of your styles */
</style>


<!DOCTYPE html>
<html>
<head>
    <title>Exam Paper</title>
    <style>
      
    </style>
</head>
<body>
    <div class="title">
        <h1><?= htmlspecialchars($COURSETRADE->name) ?> (<?= htmlspecialchars($COURSETRADE->code) ?>)</h1>
        <h2><?= htmlspecialchars($COURSE->name) ?></h2>
        <p><strong>Exam Period:</strong> <?= htmlspecialchars($EXAMPERIOD->title) ?></p>
        <hr>
    </div>

    <?php
    foreach ($all_selected_questions as $key => $question) {
        $key++;
        $QUESTION = new Question($question['qu_id']);
        $MODULE = new CourseModule($QUESTION->module_id);
    ?>
        <div class="card-body question">
            <h4 class="card-title mb-4">
                <span>
                    <?= $key . '.' ?>
                    <?php
                    if ($COURSE->english_lang == 1) {
                        echo strip_tags($QUESTION->question);
                    } elseif ($COURSE->sinhala_lang == 1) {
                        echo strip_tags($QUESTION->question_sinhala);
                    } elseif ($COURSE->tamil_lang == 1) {
                        echo strip_tags($QUESTION->question_tamil);
                    }
                    ?>
                    - <?= htmlspecialchars($MODULE->code) ?>
                    <!-- Edit button won't work in PDF but keeping for your reference -->
                    <a class="button" href="edit-questions.php?id=<?= $QUESTION->id ?>">Edit</a>
                </span>
            </h4>

            <div class="row">
                <div class="col-md-12">
                    <div class="form-check">
                        <label class="form-check-label <?= $QUESTION->correct_answer == 1 ? 'text-success' : '' ?>">
                            <?php
                            if ($COURSE->english_lang == 1) {
                                echo htmlspecialchars($QUESTION->answer_1);
                            } elseif ($COURSE->sinhala_lang == 1) {
                                echo htmlspecialchars($QUESTION->answer_1_sinhala);
                            } elseif ($COURSE->tamil_lang == 1) {
                                echo htmlspecialchars($QUESTION->answer_1_tamil);
                            }
                            ?>
                        </label>
                    </div>

                    <div class="form-check">
                        <label class="form-check-label <?= $QUESTION->correct_answer == 2 ? 'text-success' : '' ?>">
                            <?php
                            if ($COURSE->english_lang == 1) {
                                echo htmlspecialchars($QUESTION->answer_2);
                            } elseif ($COURSE->sinhala_lang == 1) {
                                echo htmlspecialchars($QUESTION->answer_2_sinhala);
                            } elseif ($COURSE->tamil_lang == 1) {
                                echo htmlspecialchars($QUESTION->answer_2_tamil);
                            }
                            ?>
                        </label>
                    </div>

                    <div class="form-check">
                        <label class="form-check-label <?= $QUESTION->correct_answer == 3 ? 'text-success' : '' ?>">
                            <?php
                            if ($COURSE->english_lang == 1) {
                                echo htmlspecialchars($QUESTION->answer_3);
                            } elseif ($COURSE->sinhala_lang == 1) {
                                echo htmlspecialchars($QUESTION->answer_3_sinhala);
                            } elseif ($COURSE->tamil_lang == 1) {
                                echo htmlspecialchars($QUESTION->answer_3_tamil);
                            }
                            ?>
                        </label>
                    </div>

                    <div class="form-check">
                        <label class="form-check-label <?= $QUESTION->correct_answer == 4 ? 'text-success' : '' ?>">
                            <?php
                            if ($COURSE->english_lang == 1) {
                                echo htmlspecialchars($QUESTION->answer_4);
                            } elseif ($COURSE->sinhala_lang == 1) {
                                echo htmlspecialchars($QUESTION->answer_4_sinhala);
                            } elseif ($COURSE->tamil_lang == 1) {
                                echo htmlspecialchars($QUESTION->answer_4_tamil);
                            }
                            ?>
                        </label>
                    </div>
                </div>
            </div>
        </div>
    <?php
    }
    ?>
</body>
</html>

<?php
$html = ob_get_clean();

$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream("exam-paper.pdf", ["Attachment" => false]);
exit;
?>
